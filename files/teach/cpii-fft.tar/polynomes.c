#include "polynomes.h"
#include <string.h> /* memcpy */
#include <math.h> /* sin et cos */

#define MAX(x,y) ((x) > (y) ? (x) : (y))

struct polynome *pn_zero(size_t taille)
{
	struct polynome *p = malloc(sizeof(struct polynome));
	if (!p)
		return NULL;
	p->coeffs = calloc(taille, sizeof(complexe));
	if (!(p->coeffs)) {
		free(p);
		return NULL;
	}
	p->deg = 0;
	p->taille = taille;
	return p;
}

int pn_est_nul(const struct polynome *p)
{
	return p->deg == 0 && p->coeffs[0] == 0;
}

void pn_liberer(struct polynome *p)
{
	if (p) {
		free(p->coeffs);
		free(p);
	}
}

int pn_set_coeff(struct polynome *p, size_t i, complexe coeff)
{
	if (p->deg < i && coeff == 0)
		return 0;
	if (p->taille <= i) {
		pn_agrandir(p, i + 1);
	}
	p->coeffs[i] = coeff;
	if (p->deg < i && coeff != 0)
		p->deg = i;
	if (p->deg == i && coeff == 0)
		while(p->coeffs[(p->deg)] == 0 && p->deg-- > 0)
			;
	return 0;
}

int pn_agrandir(struct polynome *p, size_t min_taille)
{
	size_t sz = p->taille, k;
	complexe *r;
	if (p->taille >= min_taille)
		return 0;
	while (sz < min_taille)
		sz *= 2;
	if (!(r = realloc(p->coeffs, sz * sizeof(complexe))))
		return -1;
	for (k = p->taille; k < sz; ++k)
		r[k] = 0;
	p->taille = sz;
	p->coeffs = r;
	return 0;
}

struct polynome *pn_copie(const struct polynome *p)
{
	struct polynome *q;
	if (!(q = malloc(sizeof(struct polynome))))
		return NULL;
	if (!(q->coeffs = malloc(p->taille * sizeof(complexe)))) {
		free(q);
		return NULL;
	}
	memcpy(q->coeffs, p->coeffs, p->taille * sizeof(complexe));
	q->deg = p->deg;
	q->taille = p->taille;
	return NULL;
}

char *sprint_cplx(char *s, complexe z)
{
	double r = creal(z), i = cimag(z);
	if (!i) {
		sprintf(s, "%g", r);
		return s;
	}
	if (!r) {
		sprintf(s, "%gI", i);
		return s;
	}
	sprintf(s, "(%g + %gI)", r, i);
	return s;
}

void print_cplx(complexe z)
{
	double r = creal(z), i = cimag(z);
	if (!i) {
		printf("%g", r);
		return;
	}
	if (!r) {
		printf("%gI", i);
		return;
	}
	printf("(%g + %gI)", r, i);
}

void pn_afficher(const struct polynome *p)
{
	size_t k;
	complexe cf;
	for (k = p->deg; k > 0; --k) {
		cf = p->coeffs[k];
		print_cplx(cf);
		printf("X^%zu + ", k);
	}
	cf = p->coeffs[0];
	print_cplx(cf);
	puts("");
}

complexe pn_eval(const struct polynome *p, complexe z)
{
	/* algorithme assez naïf */
	complexe z_i, res = 0;
	size_t i;
	for (i = 0, z_i = 1; i <= p->deg; ++i, z_i *= z)
		res += p->coeffs[i] * z_i;
	return res;
}

complexe pn_horner(const struct polynome *p, complexe z)
{
	/* Méthode de Horner */
	complexe *cf;
	complexe y = p->coeffs[p->deg];
	for (cf = p->coeffs + p->deg - 1; cf >= p->coeffs; --cf)
		y *= z + *cf;
	return y;
}

struct polynome *pn_somme(const struct polynome *p, const struct polynome *q)
{
	struct polynome *s;
	size_t i, j;
	if (p->deg != q->deg) {
		const struct polynome *grand = q;
		const struct polynome *petit = p;
		if (p->deg > q->deg) {
			grand = p;
			petit = q;
		}
		if (!(s = pn_zero(grand->deg + 1)))
			return NULL;
		s->deg = grand->deg;
		for (i = grand->deg + 1; i > petit->deg; --i)
			s->coeffs[i] = grand->coeffs[i];
	} else {
		i = p->deg;
		while (p->coeffs[i] == -q->coeffs[i] && i-- > 0)
			;
		if (!(s = pn_zero(i + 1)))
			return NULL;
		s->deg = i;
	}
		for (j = 0; j <= i; ++j)
			s->coeffs[j] = p->coeffs[j] + q->coeffs[j];
	return s;
}

struct polynome *pn_produit(const struct polynome *p, const struct polynome *q)
{
	struct polynome *r;
	size_t i, j;
	if (pn_est_nul(p) || pn_est_nul(q))
		return pn_zero(1);
	if (!(r = pn_zero(p->deg + q->deg + 1)))
		return NULL;
	r->deg = p->deg + q->deg;
	for (i = 0; i <= p->deg; ++i)
		for (j = 0; j <= q->deg; ++j)
			r->coeffs[i + j] += p->coeffs[i] * q->coeffs[j];
	return r;
}

static complexe *somme_g_d(const complexe *p, size_t sz)
{
	complexe *res;
	size_t i;
	if (!(res = malloc(sz / 2 * sizeof(complexe))))
		return NULL;
	for (i = 0; i < sz / 2; ++i)
		res[i] = p[i] + p[sz / 2 + i];
	return res;
}

static complexe *aux_karatsuba(const complexe *p, const complexe *q, size_t sz)
{
	complexe *r, *ps, *qs, *rg, *rd, *rs;
	size_t i;
	if (sz == 1) {
		r = malloc(2 * sizeof(complexe));
		/* c'est bizarre, mais il faut préserver l'invariant
		 * taille du résultat = 2 * taille de chaque entrée */
		r[0] = p[0] * q[0];
		r[1] = 0;
		return r;
	}
	r = malloc(2 * sz * sizeof(complexe));
	ps = somme_g_d(p, sz);
	qs = somme_g_d(q, sz);
	rg = aux_karatsuba(p, q, sz / 2);
	rd = aux_karatsuba(p + sz / 2, q + sz / 2, sz / 2);
	rs = aux_karatsuba(ps, qs, sz / 2);

	memcpy(r, rg, sz * sizeof(complexe));
	memcpy(r + sz, rd, sz * sizeof(complexe));
	for (i = 0; i < sz; ++i)
		r[sz / 2 + i] += rs[i] - rd[i] - rg[i];
	free(ps); free(qs); free(rg); free(rd); free(rs);
	return r;
}

/* Sur la fonction suivante : on pourrait faire moins de copies, mais ça
 * rendrait le code un peu plus compliqué.
 * Autres solutions :
 * * enlever const et utiliser "agrandir" pour que les polynomes aient
 * la même taille.
 * * laisser à la fonction appelante la responsabilité d'appeler cette
 * fonction avec des polynomes de même taille.
 */
struct polynome *pn_karatsuba(const struct polynome *p, const struct polynome *q)
{
	complexe *ptab, *qtab;
	size_t sz = MAX(p->taille, q->taille);
	struct polynome *r;
	if (pn_est_nul(p) || pn_est_nul(q))
		return pn_zero(1);
	ptab = calloc(sz, sizeof(complexe));
	qtab = calloc(sz, sizeof(complexe));
	r = malloc(sizeof(struct polynome));
	if (!(ptab && qtab && r)) {
		free(ptab);
		free(qtab);
		free(r);
		return NULL;
	}
	memcpy(ptab, p->coeffs, p->taille * sizeof(complexe));
	memcpy(qtab, q->coeffs, q->taille * sizeof(complexe));
	r->coeffs = aux_karatsuba(ptab, qtab, sz);
	r->taille = 2 * sz;
	r->deg = p->deg + q->deg;
	free(ptab);
	free(qtab);
	return r;
}

static int fft(complexe *tab, const complexe *racines, size_t taille, size_t taille_racines)
{
	size_t i, pas = taille_racines / taille;
	complexe *aux;

	if (taille == 2) {
		complexe a = tab[0]+ tab[1];
		complexe b = tab[0] - tab[1];
		tab[0] = a;
		tab[1] = b;
		return 0;
	}

	aux = malloc(taille * sizeof(complexe));
	if (!aux)
		return -1;
	/* On sépare pairs et impairs */
	for (i = 0; i < taille; ++i)
		if (i % 2 == 0)
			aux[i / 2] = tab[i];
		else
			aux[taille / 2 + i / 2] = tab[i];

	fft(aux, racines, taille / 2, taille_racines);
	fft(aux + taille / 2, racines, taille / 2, taille_racines);

	for (i = 0; i < taille / 2; ++i) {
		tab[i] = aux[i] + racines[i * pas] * aux[taille / 2 + i];
		tab[i + taille / 2] = aux[i] - racines[i * pas] * aux[taille / 2 + i];
	}
	free(aux);
	return 0;
}

static int ifft(complexe *tab, const complexe *racines, size_t taille, size_t taille_racines)
{
	complexe *racines_inv;
	size_t i;
	if (!(racines_inv = malloc(taille_racines * sizeof(complexe))))
		return -1;
	racines_inv[0] = 1;
	for (i = 1; i < taille_racines; ++i)
		racines_inv[i] = racines[taille_racines - i];
	fft(tab, racines_inv, taille, taille_racines);
	for (i = 0; i < taille; ++i)
		tab[i] /= taille;
	free(racines_inv);
	return 0;
}

static complexe *racines_unite(size_t taille_racines)
{
	complexe *r = malloc(taille_racines * sizeof(complexe));
	size_t i;
	double theta = atan(1) * 8 / taille_racines;
	if (!r)
		return NULL;
	for (i = 0; i < taille_racines; ++i)
		r[i] = cos(i * theta) + I * sin(i * theta);
	return r;
}


struct polynome *pn_produit_fft(const struct polynome *p, const struct polynome *q)
{
	complexe *ptab, *qtab, *racines;
	size_t sz = 2 * MAX(p->taille, q->taille);
	size_t i;
	struct polynome *r;
	if (pn_est_nul(p) || pn_est_nul(q))
		return pn_zero(1);
	ptab = calloc(sz, sizeof(complexe));
	qtab = calloc(sz, sizeof(complexe));
	r = malloc(sizeof(struct polynome));
	racines = racines_unite(sz);
	if (!(ptab && qtab && r && racines)) {
		free(ptab);
		free(qtab);
		free(r);
		free(racines);
		return NULL;
	}
	memcpy(ptab, p->coeffs, p->taille * sizeof(complexe));
	memcpy(qtab, q->coeffs, q->taille * sizeof(complexe));

	fft(ptab, racines, sz, sz);
	fft(qtab, racines, sz, sz);

	for (i = 0; i < sz; ++i)
		ptab[i] *= qtab[i];

	ifft(ptab, racines, sz, sz);

	r->coeffs = ptab;
	r->taille = sz;
	r->deg = p->deg + q->deg;
	free(qtab);
	free(racines);
	return r;
}
