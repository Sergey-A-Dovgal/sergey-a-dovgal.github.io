#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "polynomes.h"

#define TEST_EVAL 0
#define TEST_HORNER 0
#define TEST_SOMME 0
#define TEST_PROD 1
#define TEST_KARA 0
#define TEST_KARA_VS_NAIF 1
#define TEST_FFT 1
#define TEST_FFT_VS_KARA 1

#define DEBTEST(chaine) printf(" *** début : %s *** \n", (chaine));
#define FINTEST(chaine) printf(" *** fin : %s *** \n", (chaine));
int main()
{
#if TEST_EVAL == 1
	{
#define NB_CARS 20 /* nombre max de caractères pour l'affichage d'un complexe */
#define Afficher_image(p, z, fonction_p_z) { \
	char ch1[NB_CARS], ch2[NB_CARS]; \
	printf("P(%s) = %s\n", sprint_cplx(ch1, z), sprint_cplx(ch2, fonction_p_z(p, z))); \
}
		struct polynome *p = pn_zero(1);
		DEBTEST("pn_eval");
		printf("Pour le polynôme P(X) = ");
		pn_afficher(p);
		Afficher_image(p, 0, pn_eval);
		Afficher_image(p, 1 + I, pn_eval);
		Afficher_image(p, -2, pn_eval);

		pn_set_coeff(p, 2, 1);
		printf("Pour le polynôme P(X) = ");
		pn_afficher(p);
		Afficher_image(p, 0, pn_eval);
		Afficher_image(p, 1 + I, pn_eval);
		Afficher_image(p, -2, pn_eval);

		pn_set_coeff(p, 0, I);
		pn_set_coeff(p, 1, 3);
		printf("Pour le polynôme P(X) = ");
		pn_afficher(p);
		Afficher_image(p, 0, pn_eval);
		Afficher_image(p, 1 + I, pn_eval);
		Afficher_image(p, -2, pn_eval);

		FINTEST("pn_eval");
		pn_liberer(p);
#undef NB_CARS
#undef Afficher_image
	}
#endif
#if TEST_HORNER == 1
	{
#define NB_CARS 20 /* nombre max de caractères pour l'affichage d'un complexe */
#define Afficher_image(p, z, fonction_p_z) { \
	char ch1[NB_CARS], ch2[NB_CARS]; \
	printf("P(%s) = %s\n", sprint_cplx(ch1, z), sprint_cplx(ch2, fonction_p_z(p, z))); \
}
		struct polynome *p = pn_zero(1);
		DEBTEST("pn_horner");
		printf("Pour le polynôme P(X) = ");
		pn_afficher(p);
		Afficher_image(p, 0, pn_horner);
		Afficher_image(p, 1 + I, pn_horner);
		Afficher_image(p, -2, pn_horner);

		pn_set_coeff(p, 2, 1);
		printf("Pour le polynôme P(X) = ");
		pn_afficher(p);
		Afficher_image(p, 0, pn_horner);
		Afficher_image(p, 1 + I, pn_horner);
		Afficher_image(p, -2, pn_horner);

		pn_set_coeff(p, 0, I);
		pn_set_coeff(p, 1, 3);
		printf("Pour le polynôme P(X) = ");
		pn_afficher(p);
		Afficher_image(p, 0, pn_horner);
		Afficher_image(p, 1 + I, pn_horner);
		Afficher_image(p, -2, pn_horner);

		FINTEST("pn_horner");
		pn_liberer(p);
#undef NB_CARS
#undef Afficher_image
	}
#endif
#if TEST_SOMME == 1
	{
		struct polynome *p = pn_zero(1), *q = pn_zero(1), *r;
		DEBTEST("somme");
		pn_set_coeff(q, 3, -2);
		pn_set_coeff(q, 2, 1);
		pn_set_coeff(q, 1, I);
		pn_set_coeff(q, 0, 10);

		pn_set_coeff(p, 3, 2);
		pn_set_coeff(p, 2, -1);
		pn_set_coeff(p, 1, 1);
		pn_set_coeff(p, 0, 0);

		pn_afficher(p);
		pn_afficher(q);

		printf("Degré de p : %zu\n", p->deg);
		printf("Degré de q : %zu\n", q->deg);

		r = pn_somme(p, q);

		printf("Degré de p + q : %zu\n", r->deg);
		pn_afficher(r);

		FINTEST("somme");
		pn_liberer(p);
		pn_liberer(q);
		pn_liberer(r);
	}
#endif
#if TEST_PROD == 1
	{
		struct polynome *p = pn_zero(1), *q = pn_zero(1), *r;
		DEBTEST("produit")
		pn_set_coeff(q, 3, -2);
		pn_set_coeff(q, 2, 1);
		pn_set_coeff(q, 1, I);
		pn_set_coeff(q, 0, 10);

		pn_set_coeff(p, 3, 2);
		pn_set_coeff(p, 2, -1);
		pn_set_coeff(p, 1, 1);
		pn_set_coeff(p, 0, 3);

		pn_afficher(p);
		pn_afficher(q);

		printf("Degré de p : %zu\n", p->deg);
		printf("Degré de q : %zu\n", q->deg);

		r = pn_produit(p, q);

		pn_afficher(r);

		FINTEST("produit")
		pn_liberer(p);
		pn_liberer(q);
		pn_liberer(r);
	}
#endif
#if TEST_KARA == 1
	{
		struct polynome *p = pn_zero(1), *q = pn_zero(1), *r;
		DEBTEST("Karatsuba")
		pn_set_coeff(q, 3, -2);
		pn_set_coeff(q, 2, 1);
		pn_set_coeff(q, 1, I);
		pn_set_coeff(q, 0, 10);

		pn_set_coeff(p, 3, 2);
		pn_set_coeff(p, 2, -1);
		pn_set_coeff(p, 1, 1);
		pn_set_coeff(p, 0, 3);

		pn_afficher(p);
		pn_afficher(q);

		printf("Degré de p : %zu\n", p->deg);
		printf("Degré de q : %zu\n", q->deg);

		r = pn_karatsuba(p, q);

		pn_afficher(r);

		FINTEST("Karatsuba")
		pn_liberer(p);
		pn_liberer(q);
		pn_liberer(r);
	}
#endif
#if TEST_KARA_VS_NAIF == 1
#define BIGN 10000
	{
		struct polynome *p = pn_zero(1), *q = pn_zero(1), *r1, *r2;
		clock_t tic, toc;
		size_t i;
		for (i = 0; i < BIGN; ++i) {
			pn_set_coeff(p, i, rand() % 10);
			pn_set_coeff(q, i, rand() % 10);
		}
		DEBTEST("Performances multiplications (naïf vs Karatsuba)");
		tic = clock();
		r1 = pn_produit(p, q);
		toc = clock();
		printf("Multiplication naïve sur polynomes de taille %d : %g\n",
				BIGN,
				(double) (toc - tic) / CLOCKS_PER_SEC);
		tic = clock();
		r2 = pn_karatsuba(p, q);
		toc = clock();
		printf("Karatsuba sur polynomes de taille %d : %g\n",
				BIGN,
				(double) (toc - tic) / CLOCKS_PER_SEC);
		FINTEST("Performances multiplications (naïf vs Karatsuba)");
		pn_liberer(p); pn_liberer(q); pn_liberer(r1); pn_liberer(r2);
	}
#endif
#if TEST_FFT == 1
	{
		struct polynome *p = pn_zero(1), *q = pn_zero(1), *r;
		DEBTEST("FFT")
		pn_set_coeff(q, 3, -2);
		pn_set_coeff(q, 2, 1);
		pn_set_coeff(q, 1, I);
		pn_set_coeff(q, 0, 10);

		pn_set_coeff(p, 3, 2);
		pn_set_coeff(p, 2, -1);
		pn_set_coeff(p, 1, 1);
		pn_set_coeff(p, 0, 3);

		pn_afficher(p);
		pn_afficher(q);

		printf("Degré de p : %zu\n", p->deg);
		printf("Degré de q : %zu\n", q->deg);

		r = pn_produit_fft(p, q);

		pn_afficher(r);

		FINTEST("FFT")
		pn_liberer(p);
		pn_liberer(q);
		pn_liberer(r);
	}
#endif
#if TEST_FFT_VS_KARA == 1
#define BIGN 10000
	{
		struct polynome *p = pn_zero(1), *q = pn_zero(1), *r1, *r2;
		double erreur = 0;
		clock_t tic, toc;
		size_t i;
		for (i = 0; i < BIGN; ++i) {
			pn_set_coeff(p, i, rand() % 10);
			pn_set_coeff(q, i, rand() % 10);
		}
		DEBTEST("Performances multiplications (Karatsuba vs FFT)");
		tic = clock();
		r1 = pn_karatsuba(p, q);
		toc = clock();
		printf("Karatsuba sur polynomes de taille %d : %g\n",
				BIGN,
				(double) (toc - tic) / CLOCKS_PER_SEC);
		tic = clock();
		r2 = pn_produit_fft(p, q);
		toc = clock();
		printf("Produit par FFT sur polynomes de taille %d : %g\n",
				BIGN,
				(double) (toc - tic) / CLOCKS_PER_SEC);

		/* Calcul de l'erreur max */
		for (i = 0; i < BIGN; ++i) {
			double err = cabs(r1->coeffs[i] - r2->coeffs[i]);
			if (erreur < err)
				erreur = err;
		}
		printf("Différence maximale entre FFT et Karatsuba : %g\n", erreur);
		FINTEST("Performances multiplications (naïf vs Karatsuba)");
		pn_liberer(p); pn_liberer(q); pn_liberer(r1); pn_liberer(r2);
	}
#endif
	return 0;
}
