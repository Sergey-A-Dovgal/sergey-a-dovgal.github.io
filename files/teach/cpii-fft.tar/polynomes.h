#ifndef POLYNOMES_H
#define POLYNOMES_H
#define MINFINI -1

#include <complex.h>
#include <stdlib.h>
#include <stdio.h>

typedef double complex complexe;

struct polynome {
	complexe *coeffs; /* tableau de taille "taille", */
	size_t deg; /* plus grand indice d'un coeff non nul, 0 si polynome nul */
	size_t taille; /* doit être une puissance de 2 > deg */
};

/* ATTENTION : pour des raison techniques, le degré d'un polynôme nul est ici 0
 * et non moins l'infini, comme cela devrait */

/* Retourne un pointeur vers un polynome initialisé au polynome nul,
 * pouvant contenir au départ taille coefficients.
 * taille doit être une puissance de 2 : 1, 2, 4, 8, ...
 * La fonction appelante doit appeler pn_liberer sur l'adresse retournée pour libérer la
 * mémoire obtenue. */
struct polynome *pn_zero(size_t taille);

/* libère la mémoire associée au polynome p */
void pn_liberer(struct polynome *p);

/* Agrandit le tableau p->coeffs à la plus petite puissance de 2 supèrieure ou
 * égale à min_taille. Les nouveaux coefficients sont nuls. */
int pn_agrandir(struct polynome *p, size_t min_taille);

/* Met le coefficient coeff à la position i pour le polynôme p
 * Si besoin, la taille de p->coeffs augmente et le degré est mis à jour
 * Retourne 0 en cas de succès et un nombre négatif en cas d'échec d'allocation
 * mémoire */
int pn_set_coeff(struct polynome *p, size_t i, complexe coeff);

/* Affiche le polynome d'adresse p sur la sortie standard */
void pn_afficher(const struct polynome *p);

/* Retourne l'évaluation du polynome d'adresse p en le complexe z */
complexe pn_eval(const struct polynome *p, complexe z);

/* Retourne l'évaluation du polynome d'adresse p en le complexe z,
 * utilise la méthode de horner */
complexe pn_horner(const struct polynome *p, complexe z);

/* Retourne l'adresse d'un polynome qui est la somme des polynomes dont les
 * adresses sont passées en argument (retourne NULL en cas d'échec des
 * allocations mémoires).
 * La fonction appelante doit appeler pn_liberer sur l'adresse retournée pour libérer la
 * mémoire obtenue. */
struct polynome *pn_somme(const struct polynome *p, const struct polynome *q);

/* Retourne l'adresse d'un polynome qui est le produit des polynomes dont les
 * adresses sont passées en argument (retourne NULL en cas d'échec des
 * allocations mémoires).
 * La fonction appelante doit appeler pn_liberer sur l'adresse retournée pour libérer la
 * mémoire obtenue. */
struct polynome *pn_produit(const struct polynome *p, const struct polynome *q);

/* Retourne l'adresse d'un polynome qui est le produit des polynomes dont les
 * adresses sont passées en argument (retourne NULL en cas d'échec des
 * allocations mémoires).
 * L'algorithme utilisé est celui de Karatsuba.
 * La fonction appelante doit appeler pn_liberer sur l'adresse retournée pour libérer la
 * mémoire obtenue. */
struct polynome *pn_karatsuba(const struct polynome *p, const struct polynome *q);

/* fonctions auxiliaires pour l'affichage de complexes */

/* Met dans s le complexe z représenté par une chaîne de caractères */
char *sprint_cplx(char *s, complexe z);
/* Affiche sur la sortie standard le complexe z représenté par une chaîne de
 * caractères */
void print_cplx(complexe z);

struct polynome *pn_produit_fft(const struct polynome *p, const struct polynome *q);
#endif
